function fetchNotifications() {
  // Aquí realizarías la llamada a la base de datos para obtener las notificaciones
  // En este ejemplo, simulamos una llamada usando setTimeout

  document.getElementById("notifications-list").innerHTML = ""; // Limpiar la lista antes de cargar nuevas notificaciones

  setTimeout(function() {
    const notifications = ["Tarea 1", "Tarea 2", "Tarea 3", "Tarea 4", "Tarea 5"];

    notifications.forEach(function(notification) {
      const li = document.createElement("li");
      li.className = "notification-item";
      li.textContent = notification;
      document.getElementById("notifications-list").appendChild(li);
    });
  }, 1000); // Simular una demora de 1 segundo en la llamada a la base de datos
}

